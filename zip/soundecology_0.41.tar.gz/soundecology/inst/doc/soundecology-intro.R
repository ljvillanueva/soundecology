
## ----results='show', message=FALSE, warning=FALSE------------------------
#Load the package
library(soundecology)

#Call the Wave object into memory
data(tropicalsound)

#Run the function
acoustic_complexity(tropicalsound)


## ----results='show', message=FALSE, warning=FALSE------------------------
#Analyze the file only for the frequencies below 8000 Hz
acoustic_complexity(tropicalsound, max_freq = 8000)


## ----results='show', message=FALSE, warning=FALSE------------------------
#Analyze the file with a cluster size of 10 seconds
acoustic_complexity(tropicalsound, j = 10)


## ----results='show', message=FALSE, warning=FALSE------------------------
#Analyze the file with a cluster size of 10 seconds and limiting to 6000 Hz
acoustic_complexity(tropicalsound, j = 10, max_freq = 6000)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
#Download a wave file from the web
download.file("http://1159sequoia05.fnr.purdue.edu/primer/sounds/SM87_20080420_000000.wav", destfile="SM87_20080420_000000.wav")

#Load file as an object called soundfile
soundfile <- readWave("SM87_20080420_000000.wav")

#Delete the downloaded wave file
unlink("SM87_20080420_000000.wav")

#Run the function on this object and save the results in a new variable called "soundfile.aci"
soundfile.aci <- acoustic_complexity(soundfile)

#Print the ACI value for the left channel of the wav file, stored in soundfile.aci
print(soundfile.aci$AciTotAll_left)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
data(tropicalsound)
result <- ndsi(tropicalsound)
print(result$ndsi_left)

summary(result)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
#Download a wave file from the web
download.file("http://1159sequoia05.fnr.purdue.edu/primer/sounds/SM87_20080420_000000.wav", destfile="SM87_20080420_000000.wav")

#Load file as an object called soundfile
soundfile <- readWave("SM87_20080420_000000.wav")

#Delete the downloaded wave file
unlink("SM87_20080420_000000.wav")

#Run the function on this object and save the results in a new variable called "soundfile.ndsi"
soundfile.ndsi <- ndsi(soundfile)

#Print the NDSI value for the left channel of the wav file, stored in soundfile.ndsi
print(soundfile.ndsi$ndsi_left)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
data(tropicalsound)
bioindex <- bioacoustic_index(tropicalsound)
print(bioindex$left_area)

summary(bioindex)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
#Download a wave file from the web
download.file("http://1159sequoia05.fnr.purdue.edu/primer/sounds/SM87_20080420_000000.wav", destfile="SM87_20080420_000000.wav")

#Load file as an object called soundfile
soundfile <- readWave("SM87_20080420_000000.wav")

#Delete the downloaded wave file
unlink("SM87_20080420_000000.wav")

#Run the function on this object and save the results in a new variable called "soundfile.bioindex"
soundfile.bioindex <- bioacoustic_index(soundfile)

#Print the Bioacoustic Index value for the left channel of the wav file, stored in soundfile.bioindex
print(soundfile.bioindex$left_area)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
data(tropicalsound)

result <- acoustic_diversity(tropicalsound)
print(result$adi_left)

summary(result)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
#Download a wave file from the web
download.file("http://1159sequoia05.fnr.purdue.edu/primer/sounds/SM87_20080420_000000.wav", destfile="SM87_20080420_000000.wav")

#Load file as an object called soundfile
soundfile <- readWave("SM87_20080420_000000.wav")

#Delete the downloaded wave file
unlink("SM87_20080420_000000.wav")

#Run the function on this object and save the results in a new variable called "soundfile.adi"
soundfile.adi <- acoustic_diversity(soundfile)

#Print the ADI value for the left channel of the wav file, stored in soundfile.adi
print(soundfile.adi$adi_left)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
data(tropicalsound)

result <- acoustic_eveness(tropicalsound)
print(result$aei_left)

summary(result)


## ----results='show', message=FALSE, warning=FALSE------------------------
library(soundecology)
#Download a wave file from the web
download.file("http://1159sequoia05.fnr.purdue.edu/primer/sounds/SM87_20080420_000000.wav", destfile="SM87_20080420_000000.wav")

#Load file as an object called soundfile
soundfile <- readWave("SM87_20080420_000000.wav")

#Delete the downloaded wave file
unlink("SM87_20080420_000000.wav")

#Run the function on this object and save the results in a new variable called "soundfile.aei"
soundfile.aei <- acoustic_eveness(soundfile)

#Print the AEI value for the left channel of the wav file, stored in soundfile.aei
print(soundfile.aei$aei_left)


